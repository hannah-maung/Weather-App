package com.example.android.basicweather

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val weatherListRV = findViewById<RecyclerView>(R.id.rv_weather_list)
        weatherListRV.layoutManager = LinearLayoutManager(this)
        weatherListRV.setHasFixedSize(true)

        val adapter = WeatherAdapter()
        weatherListRV.adapter = adapter

        adapter.addWeather(Weather("FEB 8", "75°F",  "61°F", "19% precip.","Mostly Sunny", "High chance of morning showers and will clear up later in the day."))
        adapter.addWeather(Weather("FEB 7", "77°F",  "63°F", "16% precip.","Partly Cloudy", "Sunny in the morning with a high chance of cloudy skies in the afternoon and evening."))
        adapter.addWeather(Weather("FEB 6", "81°F",  "71°F", "24% precip.","Mostly Cloudy", "Cloudy skies all day with a slight chance of the sun peaking out in the late afternoon."))
        adapter.addWeather(Weather("FEB 5", "79°F",  "69°F", "20% precip.","Very Sunny", "Very sunny all day with a low chance of clouds in the morning."))
        adapter.addWeather(Weather("FEB 3", "76°F",  "63°F", "25% precip.","Mostly Cloudy", "Cloudy skies with a high chance of morning and afternoon showers. Will clear up later in the day. "))
        adapter.addWeather(Weather("FEB 3", "78°F",  "65°F", "12% precip.","Partly Cloudy", "Slight chance of rain in the early morning. Expect clouds for the majority of the day."))
        adapter.addWeather(Weather("FEB 2", "80°F",  "69°F", "18% precip.","Very Sunny", "Sunniest and hottest day of the week. Expect extreme sun with a slight chance of a cloudy morning."))
        adapter.addWeather(Weather("FEB 1", "84°F",  "70°F", "11% precip.","Partly Cloudy", "Cloudy skies in the evening with a high chance of slight sun in the morning. "))


/*
        val itemTouchCallback = object  : ItemTouchHelper.SimpleCallback(
            0,
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.absoluteAdapterPosition
                val deleteWeather = adapter.deleteWeather(position)
                Snackbar.make(coordinatorLayout,"Deleted: ${deleteWeather.longDescription}", Snackbar.LENGTH_SHORT).show()
            }
        }

        val itemTouchHelper = ItemTouchHelper(itemTouchCallback)
        itemTouchHelper.attachToRecyclerView(weatherListRV)*/

    }
}



