package com.example.android.basicweather

data class Weather(

    val date: String,
    val highTemp: String,
    val lowTemp: String,
    val probabilityPrecipitation: String,
    val shortDescription: String,
    val longDescription: String

)
