package com.example.android.basicweather
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.snackbar.Snackbar

class WeatherAdapter: RecyclerView.Adapter<WeatherAdapter.ViewHolder>(){

    private val weathers : MutableList<Weather> = mutableListOf()

    override fun getItemCount() = this.weathers.size

    fun addWeather(weather: Weather){
        this.weathers.add(0, weather)
        this.notifyItemInserted(0)

    }

    fun deleteWeather(position: Int): Weather {
        val weather = this.weathers.removeAt(position)
        this.notifyItemRemoved(position)
        return weather

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.weather_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int)
    { holder.bind(this.weathers[position]) }


    inner class ViewHolder(view:View) : RecyclerView.ViewHolder(view){


        private val card: MaterialCardView = view.findViewById(R.id.individual_card)

        init {
           view.setOnClickListener{
               Snackbar.make(view, weathers[position].longDescription, Snackbar.LENGTH_LONG).show()

           }
        }

        private val weatherDateTV: TextView = view.findViewById(R.id.tv_weather_date)
        private val weatherhighTempTV: TextView = view.findViewById(R.id.tv_weather_highTemp)
        private val weatherlowTempTV: TextView = view.findViewById(R.id.tv_weather_lowTemp)
        private val weatherprobabilityPrecipitation: TextView = view.findViewById(R.id.tv_weather_probabilityPrecipitation)
        private val weathershortDescription: TextView = view.findViewById(R.id.tv_weather_shortDescription)
        private val weatherLongDescription: TextView = view.findViewById(R.id.tv_weather_longDescription)

        fun bind(weather: Weather){
            this.weatherDateTV.text = weather.date
            this.weatherhighTempTV.text = weather.highTemp
            this.weatherlowTempTV.text = weather.lowTemp
            this.weatherprobabilityPrecipitation.text = weather.probabilityPrecipitation
            this.weathershortDescription.text = weather.shortDescription
            this.weatherLongDescription.text = weather.longDescription


        }
    }

}

