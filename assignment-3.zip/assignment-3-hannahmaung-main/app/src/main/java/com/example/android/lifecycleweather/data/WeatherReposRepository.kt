package com.example.android.lifecycleweather.data

import android.text.TextUtils
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.w3c.dom.Text
import java.lang.Exception

class WeatherReposRepository(
    private val service: WeatherService,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO

) {

    suspend fun loadWeatherResults(
        location: String,
        units: String
    ): Result<FiveDayForecast> =
        withContext(ioDispatcher){
            try{
                val results = service.searchWeather(location, units,"06fbfc39ff189079603d4a61e2a9bdc4")
                Result.success(results)
            }catch(e:Exception){
                Result.failure(e)
            }
        }

}