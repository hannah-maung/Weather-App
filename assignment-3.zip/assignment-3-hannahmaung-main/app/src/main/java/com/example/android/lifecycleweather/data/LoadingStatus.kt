package com.example.android.lifecycleweather.data

enum class LoadingStatus {
    LOADING, ERROR, SUCCESS
}