package com.example.android.lifecycleweather.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.android.lifecycleweather.data.*
import kotlinx.coroutines.launch

class WeatherSearchViewModel : ViewModel(){

    private val weather = WeatherReposRepository(WeatherService.create())

    private val _weatherResults = MutableLiveData<FiveDayForecast?>(null)
    val weatherResults: LiveData<FiveDayForecast?> = _weatherResults

    private val _loadingStatus = MutableLiveData(LoadingStatus.SUCCESS)
    val loadingStatus: LiveData<LoadingStatus> = _loadingStatus


    fun loadResults(
        location: String,
        units: String
    ){
        viewModelScope.launch {
            val result = weather.loadWeatherResults(location, units)
            _weatherResults.value = result.getOrNull()
            _loadingStatus.value = when (result.isSuccess) {
                true -> LoadingStatus.SUCCESS
                false -> LoadingStatus.ERROR
            }
        }

    }
}