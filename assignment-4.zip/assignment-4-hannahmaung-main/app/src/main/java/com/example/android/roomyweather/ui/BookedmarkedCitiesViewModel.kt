package com.example.android.roomyweather.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.android.roomyweather.data.AppDatabase
import com.example.android.roomyweather.data.BookedmarkedCities
import com.example.android.roomyweather.data.WeatherDatabase
import kotlinx.coroutines.launch


class BookedmarkedCitiesViewModel(application: Application) : AndroidViewModel(application) {
    private val cities = BookedmarkedCities(
        AppDatabase.getInstance(application).weatherDao()
    )
    val bookmarkedCities = cities.getallBookedmarkedCities().asLiveData()

    fun addBookedmarkedCity(weatherDatabase: WeatherDatabase){
        viewModelScope.launch {
            cities.insertBookedmarkedCities(weatherDatabase)
        }
    }

    fun removeBookedmarkedCity(weatherDatabase: WeatherDatabase){
        viewModelScope.launch {
            cities.removeBookedmarkedCities(weatherDatabase)
        }
    }

}