package com.example.android.roomyweather.data

class BookedmarkedCities(

    private val dao: WeatherDao
) {

    suspend fun insertBookedmarkedCities(weatherDatabase: WeatherDatabase) = dao.insert(weatherDatabase)
    suspend fun removeBookedmarkedCities(weatherDatabase: WeatherDatabase) = dao.delete(weatherDatabase)
    fun getallBookedmarkedCities() = dao.getAllCities()
    fun getBookmarkedCityByName(city: String) = dao.getCitiesByName(city)

}
