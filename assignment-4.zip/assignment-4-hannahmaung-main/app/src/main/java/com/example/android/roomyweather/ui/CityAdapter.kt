package com.example.android.roomyweather.ui

import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.example.android.roomyweather.R
import com.example.android.roomyweather.data.WeatherDatabase


class CityAdapter(private val onClick: (WeatherDatabase) -> Unit)
    : RecyclerView.Adapter<CityAdapter.ViewHolder>() {

    var bookmarkedCitiesList: List<WeatherDatabase> = listOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.city_list_item, parent, false)
        return ViewHolder(view, onClick)
    }

    @RequiresApi(Build.VERSION_CODES.N)
    fun updateCities(newDBCityEntry: List<WeatherDatabase>?) {
        if (newDBCityEntry != null) {
            bookmarkedCitiesList = newDBCityEntry.sortedWith(compareBy<WeatherDatabase> {it.timestamp}.reversed())
        }
        notifyDataSetChanged()
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(this.bookmarkedCitiesList[position])
    }

    override fun getItemCount() = this.bookmarkedCitiesList.size

    class ViewHolder(itemView: View, val onClick: (WeatherDatabase) -> Unit) :
        RecyclerView.ViewHolder(itemView) {
        private val cityName: TextView = itemView.findViewById(R.id.city_name)
        private var currentCityPeriod: WeatherDatabase? = null

        init {
            itemView.setOnClickListener {
                currentCityPeriod?.let(onClick)
            }
        }

        fun bind(weatherDatabase: WeatherDatabase) {
            currentCityPeriod = weatherDatabase
            cityName.text = weatherDatabase.city

        }
    }
}

