package com.example.android.roomyweather.data

import androidx.room.Entity
import java.sql.Timestamp
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity
data class WeatherDatabase(

    @PrimaryKey
    val city: String,
    val timestamp: Long

) : Serializable


