package com.example.android.roomyweather.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface WeatherDao {

    @Insert (onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(weatherDatabase: WeatherDatabase)

    @Delete
    suspend fun delete(weatherDatabase: WeatherDatabase)

    @Query("SELECT * From WeatherDatabase")
    fun getAllCities(): Flow<List<WeatherDatabase>>

    @Query("SELECT * FROM WeatherDatabase WHERE city = :city LIMIT 1")
    fun getCitiesByName(city: String): Flow<WeatherDatabase?>

}