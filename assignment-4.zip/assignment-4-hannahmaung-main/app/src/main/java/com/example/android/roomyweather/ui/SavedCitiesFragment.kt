package com.example.android.roomyweather.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.android.roomyweather.R
import androidx.navigation.fragment.findNavController
import com.example.android.roomyweather.data.ForecastPeriod
import com.example.android.roomyweather.data.WeatherDatabase

class SavedCitiesFragment : Fragment() {

    private val listAdapter = CityAdapter(::onForecastClick)
    private lateinit var forecastAdapter: ForecastAdapter
    private lateinit var bookmarkedCitiesRV: RecyclerView

    private val viewModel: BookedmarkedCitiesViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
//
//        bookmarkedCitiesRV = view.findViewById(R.id.rv_city_list)
//        bookmarkedCitiesRV.layoutManager = LinearLayoutManager(requireContext())
//        bookmarkedCitiesRV.setHasFixedSize(true)
//        bookmarkedCitiesRV.adapter = this.listAdapter
//
//        viewModel.bookmarkedCities.observe(viewLifecycleOwner) { bookmarkedCities ->
//            listAdapter.updateCities(bookmarkedCities)
//        }
    }

    private fun onForecastClick(weatherDatabase: WeatherDatabase) {

    }
}