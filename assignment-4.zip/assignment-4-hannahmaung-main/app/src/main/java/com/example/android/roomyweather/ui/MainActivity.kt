package com.example.android.roomyweather.ui
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.android.roomyweather.R
import com.example.android.roomyweather.data.WeatherDatabase
import com.google.android.material.navigation.NavigationView


class MainActivity : AppCompatActivity() {

    private val tag = "MainActivity"

    private val viewModelC: BookedmarkedCitiesViewModel by viewModels()
    private lateinit var cityAdapter: CityAdapter

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var bookmarkedCitiesRV: RecyclerView


    @RequiresApi(Build.VERSION_CODES.N)

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        val navHostFragment: NavHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        appBarConfiguration = AppBarConfiguration(navController.graph,drawerLayout)

        setupActionBarWithNavController(navController,appBarConfiguration)

        findViewById<NavigationView>(R.id.nav_view).setupWithNavController(navController)
        bookmarkedCitiesRV = findViewById(R.id.rv_city_list)
        bookmarkedCitiesRV.layoutManager = LinearLayoutManager(this)
        bookmarkedCitiesRV.setHasFixedSize(true)

        cityAdapter = CityAdapter(::onCityItemClick)
        bookmarkedCitiesRV.adapter = cityAdapter

        viewModelC.bookmarkedCities.observe(this) { bookmarkedCities ->
            this.cityAdapter.updateCities(bookmarkedCities)
        }
    }


    private fun onCityItemClick(weatherDatabase: WeatherDatabase) {

        Log.e("Testing","OnClick Called")


        val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this)
        var city = sharedPrefs.getString(getString(R.string.pref_city_key), "Corvallis,OR,US")
        val cityEntry = WeatherDatabase(city!!, System.currentTimeMillis())
        var units = sharedPrefs.getString(getString(R.string.pref_units_key), null)

        viewModelC.addBookedmarkedCity(cityEntry)
//        val editor = sharedPrefs.edit()
//        editor.putString("city",city).apply()

        with (sharedPrefs.edit()){
            putString(getString(R.string.pref_city_key), cityEntry.city)
            apply()
        }

        city = sharedPrefs.getString(getString(R.string.pref_city_key), "Corvallis,OR,US")
        units = sharedPrefs.getString(getString(R.string.pref_units_key), null)
        findViewById<DrawerLayout>(R.id.drawer_layout).closeDrawers()

    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()

    }

}

