package com.example.android.connectedweather

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.android.connectedweather.data.ForecastPeriod
import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

const val EXTRA_WEATHER_REPO = "ForecastPeriod"

class RepoDetailActivity : AppCompatActivity() {

    private var repo: ForecastPeriod? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_repo_detail)

        if (intent !=null && intent.hasExtra(EXTRA_WEATHER_REPO)) {
            repo = intent.getSerializableExtra(EXTRA_WEATHER_REPO) as ForecastPeriod
            findViewById<TextView>(R.id.tv_repo_name).text = repo!!.dt_txt
            findViewById<TextView>(R.id.tv_repo_pop).text = repo!!.pop.plus("%precip")
            findViewById<TextView>(R.id.tv_repo_tempmax).text = repo!!.main.temp_max.toString().plus("°F")
            findViewById<TextView>(R.id.tv_repo_tempmin).text = repo!!.main.temp_min.toString().plus("°F")
            findViewById<TextView>(R.id.tv_repo_wind).text = repo!!.wind.speed.toString().plus("mph")
            findViewById<TextView>(R.id.tv_repo_description).text = repo!!.weather.get(0).shortDescription



        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.activity_repo_detail,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.action_view_repo -> {
                viewRepoOnWeb()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
    }

    private fun viewRepoOnWeb(){
        if(repo != null){
            val uri = Uri.parse("https://www.google.com/maps/place/Beaverton,+OR/data=!4m2!3m1!1s0x5495082476f88863:0x10e0cf158aacbd08?sa=X&ved=2ahUKEwj-5734-Oz1AhX3CTQIHZJKAnAQ8gF6BAgCEAE")
            val intent: Intent = Intent(Intent.ACTION_VIEW,uri)
            startActivity(intent)
        }
    }

}