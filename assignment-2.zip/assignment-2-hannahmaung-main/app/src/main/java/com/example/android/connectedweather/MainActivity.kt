package com.example.android.connectedweather
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.android.connectedweather.data.ForecastPeriod
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.squareup.moshi.Moshi
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class MainActivity : AppCompatActivity() {

    private val apiBaseUrl = "https://api.openweathermap.org"
    private val tag = "MainActivity"

    private val repoListAdapter = ForecastAdapter(::onWeatherRepoClick)

    private lateinit var requestQueue: RequestQueue

    private lateinit var searchResultsListRV: RecyclerView
    private lateinit var searchErrorTV: TextView
    private lateinit var loadingIndicator: CircularProgressIndicator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestQueue = Volley.newRequestQueue(this)

        val forecastListRV = findViewById<RecyclerView>(R.id.rv_forecast_list)

        searchErrorTV = findViewById(R.id.tv_search_error)
        loadingIndicator = findViewById(R.id.loading_indicator)

        forecastListRV.layoutManager = LinearLayoutManager(this)
        forecastListRV.setHasFixedSize(true)

        forecastListRV.adapter = repoListAdapter

        doRepoSearch("Beaverton,OR,US&units=Imperial&appid=06fbfc39ff189079603d4a61e2a9bdc4")
    }


    fun doRepoSearch(q: String, sort: String = "stars"){
        val url = "$apiBaseUrl/data/2.5/forecast?q=$q&sort=$sort"

        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()

        val jsonAdapter: JsonAdapter<WeatherResults> =
            moshi.adapter(WeatherResults::class.java)

        val req = StringRequest(
            Request.Method.GET,
            url,
            {
                val results = jsonAdapter.fromJson(it)
                Log.d(tag, results.toString())
                repoListAdapter.updateRepoList(results?.list)

                loadingIndicator.visibility = View.INVISIBLE

                //searchResultsListRV.visibility = View.INVISIBLE
                //Log.d(tag,it)
            },
            {
                Log.d(tag, "Error fetching from $url: ${it.message}")
                loadingIndicator.visibility = View.INVISIBLE
                searchErrorTV.visibility = View.VISIBLE
            }
        )
        loadingIndicator.visibility = View.VISIBLE
        //searchResultsListRV.visibility = View.VISIBLE
        searchErrorTV.visibility = View.VISIBLE
        requestQueue.add(req)
    }

    private fun onWeatherRepoClick(repo:ForecastPeriod){
        val intent = Intent(this, RepoDetailActivity::class.java).apply{
            putExtra(EXTRA_WEATHER_REPO, repo)
        }
        startActivity(intent)
    }

    private data class WeatherResults(
        val list: List<ForecastPeriod>
    )
}