package com.example.android.connectedweather.data
import com.squareup.moshi.Json
import java.io.Serializable


data class ForecastPeriod(

    val pop: String,
    val dt_txt: String,
    val dt: String,
    val main: MainClass,
    val wind: WindClass,
    val weather: List<WeatherClass>,

):Serializable

data class MainClass(

    val temp_min : Double,
    val temp_max : Double

):Serializable

data class WindClass(

    val speed: Double

):Serializable

data class WeatherClass(

    @Json(name = "description") val shortDescription: String

):Serializable


