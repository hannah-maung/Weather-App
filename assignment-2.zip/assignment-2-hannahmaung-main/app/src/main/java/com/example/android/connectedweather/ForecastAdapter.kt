package com.example.android.connectedweather

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.android.connectedweather.data.ForecastPeriod
import com.example.android.connectedweather.data.MainClass
import com.example.android.connectedweather.data.WeatherClass
import com.google.android.material.snackbar.Snackbar
import org.w3c.dom.Text
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.Calendar

class ForecastAdapter(private val onWeatherRepoClick: (ForecastPeriod) -> Unit)
    : RecyclerView.Adapter<ForecastAdapter.ViewHolder>() {

    var weatherRepoList = listOf<ForecastPeriod>()

    fun updateRepoList(newRepoList: List<ForecastPeriod>?) {
        weatherRepoList = newRepoList ?: listOf()
        notifyDataSetChanged()
    }

    override fun getItemCount() = weatherRepoList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.forecast_list_item, parent, false)
        return ViewHolder(view, onWeatherRepoClick)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(weatherRepoList[position])
    }

    class ViewHolder(view: View, val onClick: (ForecastPeriod) -> Unit) :
        RecyclerView.ViewHolder(view) {
        private var currentForecastPeriod: ForecastPeriod? = null
        private val textTV: TextView = itemView.findViewById(R.id.tv_text)
        private val popTV: TextView = itemView.findViewById(R.id.tv_pop)
        private val tempminTV: TextView = itemView.findViewById(R.id.tv_low_temp)
        private val tempmaxTV: TextView = itemView.findViewById(R.id.tv_high_temp)
        private val descriptionTV: TextView = itemView.findViewById(R.id.tv_short_description)
        private val windTV: TextView = itemView.findViewById(R.id.tv_wind)


        init {
            itemView.setOnClickListener {
                currentForecastPeriod?.let(onClick)
            }
        }

        fun bind(forecastPeriod: ForecastPeriod) {




            //cal.setTime(sdf.parse(forecastPeriod.dateStr))
            currentForecastPeriod = forecastPeriod
            textTV.text = forecastPeriod.dt_txt
            popTV.text = forecastPeriod.pop.plus("%")
            tempminTV.text = forecastPeriod.main.temp_min.toString().plus("°F")
            tempmaxTV.text = forecastPeriod.main.temp_max.toString().plus("°F")
            descriptionTV.text = forecastPeriod.weather.get(0).shortDescription
            windTV.text = forecastPeriod.wind.speed.toString()
        }

    }


}